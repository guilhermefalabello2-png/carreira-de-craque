# v1.62.78 — Escudos da Bundesliga

- Atualizados os 18 endereços dos escudos da Bundesliga com os links fornecidos pelo usuário.
- Reutilizado o renderizador de escudos existente (`crest()`), sem criar um sistema paralelo.
- Mantida a estrutura de clubes, calendário e partidas presente na versão 1.62.77.
- Os escudos são carregados pelos endereços HTTPS informados; dependem da disponibilidade desses servidores externos.
