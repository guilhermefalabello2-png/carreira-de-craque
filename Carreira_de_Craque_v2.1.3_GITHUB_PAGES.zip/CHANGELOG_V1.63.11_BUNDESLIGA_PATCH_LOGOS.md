# Carreira de Craque v1.63.11 — Bundesliga funcional e suporte a patch de logos

- Bundesliga agora abre o centro de competição completo mesmo quando a carreira atual não é de um clube alemão.
- Adicionados seletor de rodadas, jogos da rodada, simulação manual, reinício e classificação persistida para as ligas europeias independentes.
- Bundesliga mostra G4, zona de rebaixamento e indicação de playoff para o 16º colocado.
- IDs de logos de competições alinhados aos IDs informados pelo usuário.
- O jogo não carrega mais imagens padrão de escudos/logos; deixa placeholders identificados para receber o patch.
- Sistema de patch agora aceita `crests` (clubes) e `competitionLogos` (competições) no mesmo `patch.json`.
- Mantidos os dados de clubes, elencos, uniformes, partidas e saves.
