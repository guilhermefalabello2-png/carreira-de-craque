# Carreira de Craque v1.50.2

- Removida a opção “Brasil — Série C (TESTE)” do seletor inicial “Dados do atleta > Escolher país e clube”.
- A Série C continua disponível no seletor de destino/mercado dentro da carreira (BRASIL_C), preservando sua funcionalidade durante o jogo.
- Nenhuma divisão, clube ou elenco da Série C foi removido da simulação.
