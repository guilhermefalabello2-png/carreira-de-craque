# v1.52.9 — Botão Criar Minha Carreira

- Reforça a validação dos dados e do clube antes da criação.
- O botão mostra estado de processamento e volta a ficar disponível se ocorrer uma exceção.
- Erros internos deixam de falhar silenciosamente: o usuário recebe uma mensagem e o console registra o erro para diagnóstico.
- Cache do service worker atualizado para evitar reutilização da versão anterior.

Nota: o fluxo ainda precisa ser validado dentro do aplicativo Android com as seleções reais do usuário.
