# Carreira de Craque v1.62.15 — Isolamento das ligas e escudos LaLiga

- Corrigida a identificação da liga da carreira usando também o clube real do atleta, evitando depender exclusivamente de flags antigas de saves migrados.
- Ligas > Brasil valida os participantes salvos contra os 20 clubes brasileiros esperados e reconstrói calendários contaminados.
- Ligas > Inglaterra mostra a Premier League independente quando a carreira ativa é espanhola; só exibe a tabela da carreira quando o atleta pertence a um clube inglês.
- A tabela da expansão europeia agora renderiza o escudo de cada clube, inclusive na LaLiga.
- Quando um host externo de escudo falhar, a interface mantém um emblema visível com as iniciais do clube em vez de deixar um espaço vazio.
- Não altera elencos, resultados, calendário de carreira ou dados de partidas.
