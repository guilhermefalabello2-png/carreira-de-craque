# Atualização v1.53.2 — Acessos e rebaixamentos em Ligas → Brasil

A lista de clubes em Ligas → Brasil agora acompanha as divisões persistidas da carreira. Quando a composição de uma divisão muda ou uma nova temporada começa, o calendário é reconstruído com os 20 participantes corretos. A lógica de cálculo e ordenação das tabelas foi preservada. Teste de regressão: `npm run test:promotion`.

## Atualização v1.22.8 — status pré-jogo e entrada em campo
Antes de cada partida, a central de pré-jogo informa se o atleta será titular, ficará no banco (com minuto estimado de entrada) ou não foi relacionado. Quando estiver no banco, o jogo avança automaticamente até a substituição; a participação individual começa a partir do minuto de entrada. Titulares participam desde o início e atletas não relacionados não recebem minutos.

## Atualização v1.22.6
Regra de permanência mínima: é necessário completar uma temporada inteira no clube atual antes de pedir saída ou efetivar transferência. O mercado também pode gerar propostas de clubes da Premier League; grandes clubes exigem nível e desempenho significativamente maiores.

## v1.22.5 — Brasileirão com avanço automático
- Removidos os controles “Simular rodada completa” e “Reiniciar esta Série”.
- Ao concluir uma partida da carreira, as rodadas correspondentes das Séries A e B avançam automaticamente, com resultados persistidos no aparelho.
- Acompanhar o Brasileirão não altera o resultado da partida do jogador.

## v1.22.4 — Brasileirão independente da carreira

- Brasil permanece acessível em LIGAS mesmo quando a carreira do jogador é na Inglaterra.
- Séries A e B têm calendário, resultados simulados, classificação e progresso salvos separadamente da carreira.
- Simular/reiniciar o Brasileirão não altera a carreira inglesa.
- Esta área simula os campeonatos localmente; resultados reais ao vivo exigem integração com uma API externa.

## v1.22.3 — Menu LIGAS reorganizado

- Removida a opção Europa da navegação principal.
- “Brasileirão” passou a se chamar “LIGAS”.
- Hub LIGAS separado em Brasil (Brasileirão A e B), Inglaterra (Premier League) e outras ligas com aviso “Dados do Jogador”.

## v1.22.2 — Escudos da Premier League
- Adicionados os 20 escudos PNG transparentes ESPN para os clubes ingleses.
- Os escudos aparecem nos componentes que já usam o sistema comum de emblemas.
- As imagens vêm de URLs remotas e precisam de internet para carregar.

## Premier League na carreira (v1.22.2)
A carreira pode começar em qualquer um dos 20 clubes cadastrados da Premier League. A temporada usa 38 rodadas em turno e returno, partidas jogáveis pelo motor da carreira, tabela e resultados salvos localmente. Os dados de elenco seguem o cadastro existente do projeto e podem precisar de revisão; isso não representa licenciamento oficial.

# Carreira de Craque v1.14.0 — Referências Individuais de Camisas 2026

Esta é uma atualização direta do projeto web mobile-first derivado do Carreira Craque v0.3. A estrutura HTML/CSS/JavaScript e a preparação para Capacitor foram preservadas; não é um jogo novo separado. O arquivo original está em `source/Carreira_Craque_v0.3_original.zip`.

## v1.14.0 — Referências individuais e sem camisas inventadas

- A prévia humana foi removida da seção `JOGADOR → Personalizar`; a tela é dedicada à camisa.
- Seletores de titular, reserva e terceira ficam desabilitados quando não há modelo cadastrado.
- A vista das costas só poderá ser usada quando houver imagem local para essa vista.
- O arquivo `assets/uniformes-2026/catalogo_2026.json` lista os 40 clubes e o estado real das imagens.
- **Limitação honesta:** não há fotografias oficiais licenciadas no ZIP. Palmeiras, Flamengo e São Paulo têm referências consultadas e uma prévia vetorial parcial, explicitamente identificada; os arquivos oficiais, costas e detalhes completos continuam pendentes.
- Os saves existentes e os sistemas de carreira permanecem no mesmo formato.

## Correções v1.6.0

- Transferência do atleta controlado com atualização de clube, competição, elenco, contrato, camisa, histórico e salvamento.
- Pedido de saída do clube; a carreira nunca troca de clube sem proposta e aprovação do usuário.
- Propostas automáticas em avaliações semanais, com probabilidade ligada ao desempenho e ao contexto; nenhuma proposta garantida a cada avanço.
- Bloqueio de propostas duplicadas enquanto houver uma pendente e prazo de validade corrigido.
- Central persistente de notificações com contador na barra superior, acesso posterior e avisos de proposta, recusa, expiração e transferência.
- IA de placares baseada na força base do clube, qualidade média dos melhores atletas cadastrados, mando e variação probabilística. O modo interativo continua preservado.

## Novidades desta versão

- Nova aba fixa **JOGADOR** na navegação principal, com perfil do atleta da carreira, overall, potencial estimado, valor de mercado, contrato, posição, camisa, moral, confiança, condição física e energia.
- Seções de atributos (21 atributos, com visão adaptada para goleiro), estatísticas da temporada, histórico de temporadas e partidas, situação no elenco e numeração.
- Tela de camisa com números 1–99, dono conhecido quando há número registrado, avaliação de disputa por camisa ocupada, pedido em avaliação/espera e histórico persistente. **O dono atual nunca é renumerado nem removido para liberar a camisa**: um pedido ocupado pode ficar em avaliação ou ser recusado, e só se conclui quando o número fica genuinamente livre.
- A numeração atualizada é usada no avatar, no campo ilustrado e no histórico de partidas. Ao transferir o atleta controlado, o jogo escolhe uma numeração que não conflita com os números conhecidos no elenco.
- Base local de **720 registros de atletas associados aos 40 clubes da Série A e Série B de 2026**, com 18 jogadores por clube, com identificadores únicos, fonte por clube, data de referência e números apenas quando observados em escalação ou cadastro oficial. O espelho de dados está em `data/jogadores_reais_2026.json`.
- OVR, posição de gameplay e os 21 atributos dos atletas reais são estimativas de jogo, não notas oficiais. Idade, nacionalidade, altura, pé dominante, valor de mercado e número não confirmado permanecem como “não informado”/nulo, em vez de serem inventados.
- Elenco dentro da carreira prioriza jogadores identificados na base. A base de jogo mantém 18 nomes por clube. Posições, overall e atributos são estimativas de gameplay; números de camisa só são preenchidos quando confirmados.
- Ficha individual para cada atleta do banco, com atributos de gameplay, números registrados e estatísticas simuladas de gols/assistências.
- Pesquisa por nome, filtro por posição/overall e ordenação no elenco do clube.
- Modo carreira exclusivamente do atleta: o usuário pode negociar apenas a própria carreira. A tela do elenco é somente informativa; ações para vender, dispensar, transferir ou redesignar camisas de concorrentes foram removidas/bloqueadas. Nenhum mercado de fundo de transferências de outros atletas está ativo nesta versão.
- Migração automática dos salvamentos anteriores: cria os campos do novo menu sem apagar o histórico do atleta controlado.

## Dados reais: cobertura e limites

A versão 1.4.0 inclui 18 atletas por clube (40 clubes, Série A e Série B de 2026). Os nomes foram cruzados com registros de atletas da CBF e páginas oficiais de elenco disponíveis. A posição de gameplay e as notas não são dados oficiais; são estimativas para o simulador. Confira `docs/FONTES_ELENCOS_2026.md` para as fontes consultadas.

A CBF nem sempre fornece na mesma página a numeração, a idade, a nacionalidade, a altura, o pé dominante e a posição. Portanto:

- Nomes e associação a clube foram curados a partir das fontes listadas, mas mudanças de janela/inscrição exigem nova conferência.
- A posição exibida é uma posição funcional para o motor do jogo, estimada quando a fonte não a forneceu diretamente.
- Overall e atributos são **estimativas de gameplay** e não avaliações oficiais.
- Números só são preenchidos quando apareceram numa escalação consultada ou cadastro oficial; número desconhecido não é tratado como vaga confirmada. A interface avisa que “sem ocupante identificado” não garante disponibilidade administrativa real porque a base é parcial.
- Fotos reais e escudos oficiais não foram incorporados. O jogo usa avatar CSS e iniciais/identificadores visuais.
- As estatísticas individuais de gols e assistências são criadas pelas partidas simuladas do save. Elas não são estatísticas oficiais do Brasileirão real.
- As movimentações de outros jogadores não são controláveis pelo usuário. Os dados biográficos ainda não confirmados permanecem vazios.

## Sistemas existentes preservados

- Brasileirão Série A e Série B: 20 clubes em cada, 38 rodadas e 380 partidas programadas por divisão, turno e returno.
- Simulação dos jogos restantes, classificação, artilharia/assistências geradas a partir de resultados, histórico, acesso e rebaixamento.
- Modos Automático, Híbrido e Decisões táticas; treino, lesão/suspensão, mercado de transferências do atleta controlado, contratos, notícias, carreira e salvamento local.
- Backup JSON e migração básica de salvamentos `cc_v3`/`cc_v2`.

## Testes

Execute na pasta do projeto:

```bash
npm run test:logic
```

Os testes automatizados usam DOM simulado e verificam criação da carreira, os 40 clubes, 720 registros de jogadores associados a fontes, IDs únicos, numeração conhecida sem duplicidade, tela JOGADOR, solicitação de camisa vaga, preservação do dono de camisa ocupada, bloqueio de transferências de concorrentes, persistência, motor de partida, tabelas e progressão de temporada. Isso é teste lógico, não substitui inspeção visual em navegador real nem teste em aparelho Android.

## Executar no navegador

1. Extraia o ZIP.
2. Abra `index.html` num navegador moderno. O jogo e o banco embutido funcionam offline; `data/jogadores_reais_2026.json` é um espelho legível para manutenção.
3. Os dados são guardados no armazenamento local do navegador/instalação. Exporte backups JSON regularmente.

## Preparar para Android com Capacitor

Pré-requisitos: Node.js, Android Studio e Android SDK configurados.

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

Compile pelo Android Studio. **Este pacote não contém APK compilado**: não foi possível compilar/validar um APK neste ambiente.

## Limitações conhecidas

- A base da versão 1.4.0 contém 720 registros, 18 por clube, cobrindo os 40 clubes das Séries A e B. A numeração não é completa: números desconhecidos permanecem sem confirmação. Posições e notas de gameplay são estimativas.
- Fotos reais, escudos oficiais, categorias de base completas, copas, Série C, seleções e regras de vagas continentais condicionadas às copas ainda não estão implementados.
- O motor é textual/estatístico, sem jogo 3D ou controle de ações em tempo real.
- Estatísticas de jogadores reais refletem apenas as partidas simuladas neste save, não os números oficiais da temporada fora do jogo.
- O APK e o teste em dispositivo Android não foram gerados/concluídos. O teste de renderização do relatório é feito com DOM simulado.


## v1.7.0 — Correção da saída de clube

- Corrigida a faixa de compatibilidade entre overall do atleta e nível dos clubes interessados, que bloqueava propostas para jogadores com overall inicial baixo.
- Ao solicitar saída, o empresário agora abre uma sondagem imediata e cria uma proposta de clube compatível quando existe um destino disponível.
- A transferência continua dependendo da escolha do usuário: aceitar, negociar ou recusar. O pedido não troca o clube automaticamente.
- Mantido o salvamento automático do novo clube, contrato, camisa, histórico e notificações.


### v1.8 — transferências e gerenciamento de saves
- Em Mercado, `SOLICITAR SAÍDA DO CLUBE` gera uma proposta imediata de outro clube. Abra `VER` e confirme `SIM, TRANSFERIR`.
- Em Salvar/Backup, use `GERENCIAR / APAGAR CARREIRAS` para abrir outra carreira ou apagar uma. Apagar exige confirmação SIM/NÃO e é permanente.


### Indicadores da tela inicial (v1.8.1)
A seção Início mostra PARTIDAS, GOLS, ASSISTÊNCIAS e NOTA MÉDIA. O número de partidas usa `careerStats.apps`, atualizado pelo motor de jogo apenas quando o jogador soma minutos em campo. O Overall continua disponível no perfil e em outras telas.


## Uniformes 2026 — referências individuais

A versão atual registra páginas individuais de referência para os 40 clubes e mantém imagens oficiais pendentes até que o arquivo direto e a licença de uso estejam confirmados. Consulte `docs/UNIFORMES_2026.md`. A tela não usa prévias vetoriais como se fossem fotos oficiais.


## v1.16.0 — Representação somente com camisa

A representação visual do atleta foi alterada para mostrar somente a camisa do clube com nome/apelido e número. A antiga tela de personalização física foi removida e substituída por “Camisa do jogador”. A carreira salva e os sistemas de gameplay permanecem preservados. Consulte `docs/ALTERACAO_V1.16.0_SOMENTE_CAMISA.md`.


## v1.20.1 — Premier League jogável

A área Europa inclui calendário ida e volta, simulação por rodada, classificação recalculada e persistência local por competição. Na Premier League, a tela também apresenta os elencos consolidados enviados pelo usuário, com camisa, posição e alerta para números repetidos. Como as listas vieram de informações fornecidas na conversa, não são certificadas como registros oficiais pela aplicação. A simulação da Premier League permanece separada da carreira brasileira; a integração de um jogador europeu como atleta da carreira não faz parte desta atualização.


## Bundesliga 2026/27 — integração inicial v1.62.77

A Bundesliga está disponível para iniciar carreira e jogar com 18 clubes e 34 rodadas. Consulte `CHANGELOG_V1.62.77_BUNDESLIGA_JOGAVEL.md`: os elencos atuais são provisórios (22 vagas geradas por clube), não os 396 jogadores reais auditados.


## Teste v1.63.11 — Bundesliga e patch de logos

- Bundesliga com rodadas, partidas simuláveis e classificação persistida.
- IDs de logos das oito competições solicitadas e suporte a `competitionLogos` no patch ZIP.
- Escudos locais deixam de ser exibidos por padrão; o jogo aguarda os escudos do patch.
- Para testar: abra `index.html` em um servidor local ou use o fluxo Android do projeto.
