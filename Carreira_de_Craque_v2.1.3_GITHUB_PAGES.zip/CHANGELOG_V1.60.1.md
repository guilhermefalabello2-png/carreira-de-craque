# v1.60.1 — Escudo do ABC em PNG

- Corrigido exclusivamente o arquivo do escudo do ABC: agora há uma imagem PNG local com transparência em `assets/escudos/abc.png`.
- A referência do clube ABC foi alterada para carregar o PNG local, sem depender de hospedagem externa.
- Atualizado o cache do service worker para garantir que o novo PNG seja carregado após a publicação.
- Nenhuma regra de jogo, calendário, elenco, carreira, progressão ou sistema de salvamento foi alterada.
