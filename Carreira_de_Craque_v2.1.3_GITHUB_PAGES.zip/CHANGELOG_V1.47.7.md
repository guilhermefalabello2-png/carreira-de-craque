# Carreira de Craque v1.47.7 — Flamengo

Correção visual baseada na imagem de referência enviada pelo usuário.

- Mangas pretas e gola preta.
- Corpo preto como base.
- Duas faixas vermelhas grossas, uma na parte superior e outra na parte inferior do tronco, separadas por uma faixa preta grossa.
- Barra inferior preta.
- Ajuste aplicado aos dois renderizadores da camisa, compartilhado pelo profissional e Sub-20.
