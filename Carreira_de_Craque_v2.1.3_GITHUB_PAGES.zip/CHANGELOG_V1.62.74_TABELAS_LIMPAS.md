# Carreira de Craque v1.62.74 — Telas de ligas simplificadas

- Série A Enilive, Ligue 1 e LaLiga: removidos os painéis "Escolher Competição" e "Elenco e camisas".
- Essas telas agora exibem somente o cabeçalho da competição e a tabela de classificação.
- Brasileirão Sub-20: removida a seção "Andamento do campeonato" e o painel de progresso; mantida somente a classificação.
- Nenhuma regra de calendário, simulação, pontuação ou avanço de temporada foi alterada nesta correção.
