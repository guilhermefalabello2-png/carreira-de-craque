# Carreira de Craque v1.60.8 — Ajuste do uniforme do Athletico Paranaense

- Ajustado exclusivamente o padrão visual do uniforme titular do Athletico Paranaense para corresponder melhor à referência enviada.
- Removidas as três faixas diagonais estreitas e substituídas por duas faixas diagonais vermelhas mais largas, paralelas, sobre a base preta.
- Mantidos gola e punhos vermelhos, mangas pretas e número branco.
- A alteração é aplicada pelo renderizador compartilhado de uniformes, portanto vale para Profissional e Sub-20.
- Nenhuma alteração intencional nos uniformes do Vitória, Santos, Grêmio ou Botafogo, nem nos demais sistemas do jogo.
