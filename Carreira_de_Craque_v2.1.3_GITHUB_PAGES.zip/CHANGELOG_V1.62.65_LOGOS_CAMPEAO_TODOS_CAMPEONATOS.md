# Carreira de Craque v1.62.65 — Logos na celebração de campeão

- A tela de celebração substitui o emoji genérico de troféu pela logo oficial já utilizada em **Ligas**.
- Mapeamento de logos para Brasileirão Série A, B e C, Brasileirão Sub-20, Copa do Brasil, Premier League, LaLiga e Serie A Enilive.
- A celebração é acionada para os campeonatos de liga e copa implementados, incluindo as competições europeias disponíveis.
- A validação e o reconhecimento de títulos profissionais agora também aceitam LaLiga, Serie A Enilive e Série C.
- A tela de teste de conquista permanece em **Escolher País e Clube → Área de Testes**, usando uma logo de liga no lugar do emoji.
- O registro de conquistas mantém os identificadores das competições e o ano da conquista.
