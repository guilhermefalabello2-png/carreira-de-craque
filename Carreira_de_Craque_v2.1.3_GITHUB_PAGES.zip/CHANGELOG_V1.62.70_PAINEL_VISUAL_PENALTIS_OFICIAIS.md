# Carreira de Craque v1.62.70 — Painel Visual de Pênaltis Oficiais

- Aplicado o painel visual também às disputas oficiais da Copa do Brasil.
- Placar por equipe com marcações de gol, erro e cobranças pendentes.
- Identificação visual de batedor e goleiro com camisas estilizadas.
- Fluxo em duas etapas: preparar a cobrança e tocar em **REVELAR COBRANÇA** para mostrar direção e resultado.
- Após a revelação, o botão **CONTINUAR DISPUTA** registra a cobrança e avança para a próxima.
- Mantidos a ordem escolhida do cobrador, morte súbita, placar da partida e registro de classificação.
- Atualizada a versão interna para 43.
