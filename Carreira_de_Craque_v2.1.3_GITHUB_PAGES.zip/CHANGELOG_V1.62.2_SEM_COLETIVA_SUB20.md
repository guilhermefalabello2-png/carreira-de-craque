# Carreira de Craque v1.62.2 — Coletivas desativadas no Sub-20

- Partidas do modo Sub-20 não geram coletiva pós-jogo.
- O relatório de partida do Sub-20 oferece continuar a carreira normalmente.
- A coletiva obrigatória e seus bloqueios continuam ativos no Profissional.
- Saves antigos do Sub-20 com coletiva pendente têm essa pendência limpa automaticamente.
- Nenhuma outra regra de partidas, resultados ou classificação foi alterada.
