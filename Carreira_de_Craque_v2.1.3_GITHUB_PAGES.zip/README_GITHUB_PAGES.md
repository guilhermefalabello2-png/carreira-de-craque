# Carreira de Craque v2.1.3 — GitHub Pages

Esta distribuição mantém o código do projeto v2.1.3 e prepara a publicação estática pelo GitHub Pages.

## Publicar

1. Extraia o conteúdo deste ZIP.
2. Envie **todos os arquivos e pastas** para a raiz de um repositório GitHub (a pasta `.github` também).
3. Em **Settings → Pages**, selecione **GitHub Actions** como método de publicação.
4. Envie um commit para a branch `main` ou execute manualmente o workflow **Publicar Carreira de Craque no GitHub Pages** na aba Actions.
5. Aguarde o workflow terminar e abra a URL indicada pelo GitHub Pages.

O workflow publica o conteúdo da raiz do repositório, compatível com endereços de projeto (`https://usuario.github.io/repositorio/`) e de usuário/organização.

## Observações importantes sobre o ZIP de origem

O pacote v2.1.3 recebido contém o `index.html`, `service-worker.js`, arquivos de documentação e configuração, mas não inclui as pastas `assets/`, `data/`, `tests/` nem os ícones/manifesto que o próprio código referencia. Não é possível reconstruir fielmente esses arquivos ausentes sem a distribuição completa original. Foram adicionados apenas os ícones básicos e o manifesto necessários à instalação PWA; os escudos, troféus, uniformes e demais recursos locais ausentes não foram substituídos por imagens falsas.

O service worker foi ajustado para não abortar a instalação inteira quando algum item opcional do cache não existir. Isso evita que a ausência de um arquivo listado no cache impeça o carregamento inicial do site, mas não recria os recursos ausentes.

## Testes

A estrutura e os arquivos essenciais de publicação foram conferidos. A validação funcional completa em navegador/GitHub Pages ainda depende do pacote original completo, incluindo os diretórios de recursos e testes que não vieram no ZIP recebido.
