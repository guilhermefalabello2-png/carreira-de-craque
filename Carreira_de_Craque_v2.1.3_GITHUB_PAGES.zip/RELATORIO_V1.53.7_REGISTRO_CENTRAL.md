# Relatório técnico — v1.53.7 Registro Central de Conquistas Profissionais

## Diagnóstico do código anterior

O sistema tinha mais de uma fonte para o mesmo conceito de título:

1. `finishSeason()` gravava `seasonHistory` e chamava `recordCareerTitleOnce()` quando a posição do jogador era 1.
2. `recordCareerTitleOnce()` escrevia em `careerAchievements` e incrementava `careerStats.titles`.
3. `verifiedCareerTitleCount()` recalculava o número confirmado percorrendo `seasonHistory`.
4. `historyView()` decidia se mostrava o troféu diretamente com `legacyVerifiedChampion(x)` durante a renderização, sem consultar um registro central de conquistas.

As correções anteriores reforçaram a validação dos registros históricos, mas deixaram `seasonHistory` como fonte direta de exibição e não criaram uma autoridade única persistida para novas conquistas profissionais. Assim, o registro, o contador e a interface podiam divergir. Isso é uma falha arquitetural confirmada no código. Sem o save real do usuário, não é possível afirmar qual registro específico da carreira dele originou o título indevido.

## Alterações em v1.53.7

- `professionalAchievements` passa a ser a fonte única para títulos profissionais confirmados.
- `validateProfessionalAchievement()` exige temporada finalizada, competição profissional reconhecida, classificação final coerente, jogos concluídos e o clube do registro em primeiro lugar.
- `registerProfessionalAchievement()` é idempotente por carreira + competição + temporada + ID do clube.
- `professionalClubId()` usa o código estável do catálogo de clubes quando disponível; usa slug normalizado como fallback para clubes sem ID no catálogo.
- `finishSeason()` continua sendo o ponto de integração para ligas profissionais e usa o serviço central através do adaptador compatível `recordCareerTitleOnce()`.
- `historyView()` não concede nem deduz título profissional pela tabela histórica: consulta `professionalAchievements`. O Sub-20 mantém sua regra e fonte próprias.
- Migração idempotente importa somente temporadas antigas cujo resultado final ainda pode ser comprovado; registros incertos permanecem em `seasonHistory` e não são apagados.
- Resultados de copas possuem validador separado (`validateProfessionalCupResult`), exigindo evidência final explícita e clube do jogador igual ao campeão. O código atual da carreira não contém um fluxo integrado de Copa do Brasil, portanto não são gerados títulos de copa fictícios.
- O cache do service worker foi atualizado para evitar servir a versão anterior.

## Arquivos modificados

- `index.html`
- `service-worker.js`
- `package.json`
- `tests/legacy-regression.js`
- `CHANGELOG_V1.53.7.md`
- `RELATORIO_V1.53.7_REGISTRO_CENTRAL.md`

## Testes executados

- `node tests/legacy-regression.js` — PASS: primeiro lugar, vice, quinto lugar, temporada incompleta, idempotência, histórico salvo/recarregado, UI, migração, clube histórico e regressão Sub-20.
- `node tests/standings-regression.js` — PASS.
- `node tests/promotion-relegation-ligas.js` — PASS.
- Extração do JavaScript inline + `node --check` — PASS.
- Validação sintática de `package.json` — PASS.
- `unzip -t` no ZIP final — PASS.
- `node tests/smoke-test.js` — FAIL no teste `career systems initialized with identified real roster records`. A mesma falha foi reproduzida na versão-base v1.53.1; não foi introduzida por esta alteração e permanece pendente.

Os testes são automatizados e usam dados sintéticos; não substituem o teste no navegador com o save real do usuário. O save do usuário não estava disponível para inspeção.
