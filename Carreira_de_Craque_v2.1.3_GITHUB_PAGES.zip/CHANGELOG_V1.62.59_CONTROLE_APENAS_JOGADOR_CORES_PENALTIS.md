# Carreira de Craque v1.62.59 — Controle individual nos pênaltis

- Na final de teste, o usuário controla somente a cobrança do próprio atleta.
- Cobranças dos companheiros e dos adversários são simuladas automaticamente; não há botões para escolher a direção por outros jogadores.
- Removida a faixa laranja dos botões de direção: 70% ou mais aparece em verde; abaixo de 70% aparece em vermelho.
- O botão MEIO com 45% aparece corretamente em vermelho.
- Mantida a disputa de teste com placar oficial 0 x 0, sem alterar estatísticas da carreira.
