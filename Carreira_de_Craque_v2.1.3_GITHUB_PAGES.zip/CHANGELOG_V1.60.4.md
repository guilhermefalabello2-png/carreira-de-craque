# Carreira de Craque — atualização visual 1.60.4

- Atualizados os modelos vetoriais das camisas principais de Vitória, Santos, Grêmio, Botafogo e Athletico Paranaense com base nas referências enviadas pelo usuário.
- Santos: nome e número nas costas em preto com contorno dourado.
- Mantido o mesmo renderizador de uniformes para as carreiras do profissional e do Sub-20.
- Nenhuma regra de carreira, save, elenco, calendário, partidas ou navegação foi alterada nesta atualização.
