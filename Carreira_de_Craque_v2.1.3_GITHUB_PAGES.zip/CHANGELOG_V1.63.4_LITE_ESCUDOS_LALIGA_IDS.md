# v1.63.4 LITE — Escudos LaLiga e IDs permanentes

- Integrados 20 escudos locais da LaLiga 2026/27, convertidos para WebP transparente/compacto.
- Logo oficial da competição LaLiga armazenada localmente e usada em Ligas.
- IDs espanhóis fixados explicitamente no padrão ESP-..., estáveis e independentes da ordem dos clubes.
- Seletor de destino do Mercado inclui Serie A Enilive e Bundesliga, além das ligas já disponíveis.
- Negociação reconhece clubes de todas as ligas europeias listadas.
- Mantida a versão LITE e preservados os demais dados e sistemas.
