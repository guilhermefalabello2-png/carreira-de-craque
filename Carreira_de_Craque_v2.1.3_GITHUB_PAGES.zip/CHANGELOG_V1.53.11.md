# v1.53.11 — Recuperação manual de partidas

- Corrige o bloqueio que mostrava “A partida já está em andamento” sem oferecer uma ação de recuperação.
- Se uma sessão válida estiver no intervalo, o jogo reabre o modal de intervalo.
- Para uma sessão inconsistente, oferece ao usuário retomar no intervalo quando possível, liberar apenas a sessão incompleta ou voltar sem alterar nada.
- Liberar uma sessão não marca o jogo como disputado e não grava placar; a partida permanece pendente no calendário.
- Não apaga carreiras nem limpa o armazenamento do navegador.

## Limitação de validação

Validação estática e testes automatizados locais; não foi possível executar no Samsung Galaxy S10 real.
