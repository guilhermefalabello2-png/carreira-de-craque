# Carreira de Craque v1.53.8 — Correção de quota das ligas brasileiras

- Corrige a falha ao criar carreira causada por `cc_brazil_world_leagues_v123` exceder a quota do `localStorage`.
- Os calendários independentes das Séries A, B e C agora são salvos separadamente em `cc_brazil_world_leagues_v124_A/B/C`.
- Os jogos são serializados em tuplas compactas, sem repetir nomes de campos e número da rodada em cada partida.
- A criação de uma nova carreira remove o registro independente antigo e recria os calendários compactos.
- Saves existentes são migrados preservando os placares válidos quando possível; a chave antiga só é usada como fonte de migração.
- A simulação continua guardando placares e a classificação por divisão. O save principal da carreira e os dados do Sub-20 não são apagados por esta migração.
