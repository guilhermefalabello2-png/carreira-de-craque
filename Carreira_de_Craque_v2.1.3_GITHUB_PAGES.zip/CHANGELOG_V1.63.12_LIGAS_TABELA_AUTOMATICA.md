# Carreira de Craque v1.63.12 — Ligas automáticas e tabela limpa

- Premier League, LaLiga, Serie A Enilive, Ligue 1 e Bundesliga deixam de exibir controles manuais de rodada, partidas e reinício na área **Ligas**.
- As tabelas dessas competições são atualizadas automaticamente conforme a carreira avança, sem botão de simular rodada.
- A classificação aplica a regra universal: vitória = 3 pontos, empate = 1 ponto e derrota = 0 ponto.
- Corrigida a identificação interna da Bundesliga: o cadastro usa a chave `bundes`, mas a tela tentava carregar `bundesliga`, causando falha ao abrir a tabela.
- A área **Ligas** das Séries A, B e C também fica reduzida à classificação, mantendo os seletores das divisões e o acesso à Copa do Brasil.
- Copa do Brasil permanece com seu formato e telas próprios.
- Não foram alterados os menus de calendário/partidas da carreira nem o fluxo de simulação do jogador.
