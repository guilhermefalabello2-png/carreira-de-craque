# Carreira de Craque v1.56.4 — Rodada Sub-20 Desbloqueada

- Corrige bloqueio falso de partida no Sub-20 quando um registro de calendário aparece como disputado sem registro correspondente no histórico da carreira.
- O avanço automático do Sub-20 não simula mais o confronto do atleta antes de ele jogar.
- Os outros nove jogos da rodada continuam sendo simulados normalmente.
- A rodada Sub-20 só é considerada concluída quando os dez confrontos estão concluídos.
- O resultado jogado pelo usuário é sincronizado com a tabela Sub-20 após o encerramento da partida.
- A tela do Sub-20 mostra a rodada atual e identifica jogos pendentes/aguardando a partida do usuário.
- Não apaga saves, calendários, escalações ou resultados legítimos.
