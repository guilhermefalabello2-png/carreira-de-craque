# v1.52.6 — Legado respeita a posição final

- A posição registrada no encerramento da temporada passa a ter prioridade na tela Legado.
- Um registro com 2º, 5º ou qualquer posição diferente de 1º nunca será exibido como campeão, mesmo se uma tabela histórica de outra divisão estiver inconsistente.
- O reconhecimento do título continua exigindo confirmação de campeão; nenhum clube recebe título só por força/avaliação geral.
- Cache PWA atualizado para evitar carregar o JavaScript antigo.

Validação local: sintaxe JavaScript e integridade do ZIP. Não substitui teste dentro do app com o save real.
