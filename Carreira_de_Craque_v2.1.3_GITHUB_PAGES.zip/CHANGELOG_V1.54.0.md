# Carreira de Craque v1.54.0 — Partidas Realistas e Justas

- Novo motor probabilístico compartilhado para partidas simuladas e partidas rápidas do modo carreira.
- Estrelas do clube entram como ajuste moderado, sem substituir a qualidade dos atletas.
- Overalls são avaliados por setores (ataque, meio, defesa e goleiro), com profundidade de banco.
- Fator casa, forma/prontidão e abordagem tática influenciam a expectativa de gols.
- Removido o teto artificial de três gols por tempo no motor interativo; placares altos continuam possíveis pela distribuição probabilística.
- Mantidos elencos, overalls, estrelas, tabelas, calendários, saves e demais sistemas.

## Teste estatístico automatizado
10.000 partidas independentes por cenário (60.000 partidas no total), com escalações sintéticas controladas para isolar a influência das estrelas e dos overalls. As estatísticas detalhadas estão no RELATORIO_V1.54.0.md. Não substitui teste de jogo completo no navegador/Android.
