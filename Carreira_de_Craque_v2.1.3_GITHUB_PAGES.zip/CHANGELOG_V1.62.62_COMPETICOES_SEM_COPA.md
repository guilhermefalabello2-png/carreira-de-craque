# Carreira de Craque v1.62.62 — Competições organizadas

- Removido o card/atalho da Copa do Brasil da tela **Competições**.
- A Copa do Brasil continua funcionando normalmente e acessível em **Partidas → Calendário da Temporada**, onde seus jogos já aparecem destacados em azul.
- Removida a menção à Copa do Brasil do aviso inferior dessa tela.
- Preservadas as demais funções, tabelas, metas, histórico, sistema de pênaltis e dados da carreira.
