# v1.46.0 — Série C integrada

- Nova divisão nacional com 20 clubes e calendário de 38 rodadas.
- Tabela, artilharia, assistências e estatísticas da Série C acessíveis na tela Ligas.
- Promoção e rebaixamento integrados entre as Séries A, B e C.
- Histórico anual arquiva campeão, tabela e calendário da Série C.
- Migração de saves anteriores inicializa a Série C sem substituir o calendário ativo A/B.
