# Carreira de Craque v1.56.3 — Sincronização real do Sub-20

- Corrigida a divergência entre o placar da partida do jogador e a classificação independente do Brasileirão Sub-20.
- O confronto do clube do usuário no Sub-20 agora importa o placar já concluído no calendário da carreira, respeitando mando de campo.
- Os outros nove jogos da rodada continuam sendo simulados normalmente.
- A classificação continua sendo calculada a partir dos resultados da própria tabela Sub-20.
- Não altera calendários, elencos, saves, armazenamento ou regras das demais competições.
