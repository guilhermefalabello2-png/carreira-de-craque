# v1.54.1 — Correção de validação de títulos do Sub-20

- Corrigida divergência entre a ordenação oficial da tabela Sub-20 e a ordenação usada na validação de Conquistas.
- A posição final registrada agora é obtida diretamente da mesma tabela ordenada exibida no campeonato.
- A validação de títulos Sub-20 usa exatamente os critérios oficiais do cálculo da base (pontos, vitórias, saldo, gols pró e ordem alfabética), sem aplicar critérios extras de outras ligas.
- Registros antigos inconsistentes deixam de ser exibidos como títulos confirmados.
- Nenhuma partida, elenco, calendário ou save é apagado ou reiniciado.
