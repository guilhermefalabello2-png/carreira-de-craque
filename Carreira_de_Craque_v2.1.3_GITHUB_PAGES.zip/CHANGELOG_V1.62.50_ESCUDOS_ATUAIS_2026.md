# v1.62.50 — Escudos atuais 2026

- Athletico Paranaense: substituída a referência antiga pelo escudo atual (identidade CAP de quatro faixas diagonais).
- Atlético Goianiense: substituída a referência antiga pelo escudo atual do Dragão.
- Goiás: substituída a referência antiga pela imagem oficial disponibilizada no site do clube.
- Removidos os mapeamentos locais antigos desses três clubes para impedir que eles tenham prioridade sobre os novos arquivos.
- URLs incluídas no pré-cache do Service Worker; após carregarem com internet, ficam disponíveis offline.
- Cache versionado para forçar a atualização.

Observação: os arquivos remotos não puderam ser baixados/inspecionados visualmente neste ambiente sem DNS. As fontes e URLs foram atualizadas, mas o cache offline depende de uma primeira conexão bem-sucedida.
