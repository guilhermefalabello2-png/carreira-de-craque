# v1.62.83 — Ajuste de tamanho de dois escudos

- SV Elversberg: reduzido para o mesmo limite visual do escudo do Bayern Munich.
- FC Augsburg: ampliado para ocupar o mesmo limite visual de referência do Bayern Munich.
- Nenhum outro escudo, código, sistema ou save foi alterado.
