# Carreira de Craque v1.51.2 — correção de Legado e temporadas na Inglaterra

- O Legado consulta primeiro a classificação salva da temporada e competição correspondente, evitando exibir troféu profissional quando a posição real não foi 1º lugar.
- A exibição de troféu continua condicionada à posição final ser 1º lugar.
- Transferências para clubes da Premier League agora ativam explicitamente o modo Inglaterra e associam o jogador a um calendário com os 20 clubes ingleses.
- Ao carregar uma carreira inglesa com calendário incompatível ou sem o clube do atleta, o jogo reconstrói o calendário da Premier League para desbloquear a carreira.
- O botão de nova temporada recupera um calendário inglês ausente para o clube em vez de manter o usuário preso na mensagem de temporada em andamento.

Validação: sintaxe JavaScript e integridade do ZIP verificadas; sem teste visual completo no aparelho.
