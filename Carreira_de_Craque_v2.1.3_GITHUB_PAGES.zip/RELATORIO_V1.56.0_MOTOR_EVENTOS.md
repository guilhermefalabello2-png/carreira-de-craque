# Relatório de validação — v1.56.0

## Motor e integração
O placar, os chutes, os chutes no alvo, as defesas e a posse agora são produzidos pelo mesmo `simulateMatchEngine`. No Modo Realismo, a mesma função é chamada pelo calendário profissional, Sub-20, divisões brasileiras paralelas, ligas europeias e partida do atleta. O modo desligado mantém o caminho anterior.

## 60.000 simulações automatizadas
Cada cenário executou 10.000 partidas, com o primeiro clube como mandante. Elencos sintéticos controlados para comparar estrelas e overall.

| Cenário | Vitória mandante | Empate | Vitória visitante | Gols/jogo | Goleadas (dif. ≥3) |
|---|---:|---:|---:|---:|---:|
| 5★ x 1★ | 84,11% | 12,63% | 3,26% | 2,657 | 36,34% |
| 4★ x 2★ | 64,91% | 23,18% | 11,91% | 2,317 | 17,77% |
| 3★ x 3★ | 36,40% | 29,44% | 34,16% | 2,185 | 8,44% |
| 2★ x 2★ | 38,31% | 26,95% | 34,74% | 2,525 | 10,58% |
| Estrelas iguais, OVR diferente | 64,81% | 23,62% | 11,57% | 2,234 | 16,31% |
| Estrelas diferentes, OVR semelhante | 40,47% | 28,35% | 31,18% | 2,171 | 8,78% |

Média geral de finalizações: 15,56 por jogo. Média geral de defesas: 2,56 por jogo. Em 100% das partidas testadas, gols no placar = gols registrados nas estatísticas; chutes no alvo não excederam finalizações; gols não excederam chutes no alvo; a posse somou 100%.

## Placares mais comuns (percentual por cenário)
- 5★ x 1★: 2–0 (20,42%), 1–0 (16,15%), 3–0 (15,66%), 4–0 (9,10%).
- 4★ x 2★: 1–0 (17,12%), 2–0 (14,68%), 1–1 (10,62%), 0–0 (9,53%).
- 3★ x 3★: 1–1 (13,99%), 1–0 (12,51%), 0–1 (12,28%), 0–0 (10,88%).
- 2★ x 2★: 1–1 (13,50%), 1–0 (10,16%), 0–1 (9,87%), 2–1 (8,66%).
- Estrelas iguais, OVR diferente: 1–0 (18,46%), 2–0 (14,42%), 0–0 (10,51%), 1–1 (10,17%).
- Estrelas diferentes, OVR semelhante: 1–1 (13,17%), 1–0 (13,02%), 0–1 (11,57%), 0–0 (10,76%).

## Testes de regressão
- PASS: sintaxe JavaScript em `index.html` e `index_debug.html`.
- PASS: `realism-mode-regression.js` (60.000 partidas e coerência de estatísticas).
- PASS: `event-engine-integration.js` (todos os pontos de entrada apontam para o motor central).
- PASS: `match-recovery-regression.js`.
- PASS: `storage-compaction-regression.js`.
- PASS: `quota-regression.js`.
- PASS: `standings-regression.js`.
- PASS: `promotion-relegation-ligas.js`.
- Os testes legados `full-match-test.js` e `legacy-regression.js` não passaram no ambiente Node fornecido: o primeiro depende de um módulo/export `newCareer` ausente no harness; o segundo falha em uma asserção anterior ao fluxo do motor. Não foram contabilizados como aprovados.

## Limitação
Os resultados estatísticos usam elencos sintéticos e não substituem teste manual de uma temporada Android com todos os elencos reais. A gravação do Brasfoot foi usada como referência observacional de fluxo de partida, relógio, posse, finalizações, escalação, banco, condição física e comandos táticos. Nenhum código proprietário foi copiado.
