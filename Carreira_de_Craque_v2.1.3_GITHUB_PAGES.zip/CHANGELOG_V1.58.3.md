# v1.58.3 — Coletiva aparece imediatamente na tela Início

- Ao finalizar uma partida com participação do atleta, a pendência da coletiva é gravada e a tela Início é renderizada imediatamente antes da abertura do relatório pós-jogo.
- Ao fechar o relatório pelo botão “IR PARA INÍCIO”, a tela é renderizada novamente e o botão da coletiva recebe seu evento de clique diretamente.
- A trava de progressão até concluir a coletiva foi preservada.
