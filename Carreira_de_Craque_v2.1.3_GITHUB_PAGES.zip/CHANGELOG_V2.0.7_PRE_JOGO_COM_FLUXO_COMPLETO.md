# v2.0.7 — Pré-jogo com fluxo completo

- Na tela Início, o cartão do próximo compromisso agora apresenta apenas **IR A PARTIDA**.
- O botão abre uma apresentação de pré-jogo com os dois clubes, escudos, estádio, data, horário, transmissão, arbitragem e VAR.
- O botão inferior **COMEÇAR JOGO** inicia a partida somente quando chega o dia marcado.
- Se o dia ainda não chegou, o botão avança o calendário até a data da partida e retorna à apresentação pré-jogo.
- Mantidas as opções de escalação, modo de partida e plano tático dentro do pré-jogo.
- O mesmo fluxo **IR A PARTIDA** foi aplicado ao cartão da aba Partidas.
