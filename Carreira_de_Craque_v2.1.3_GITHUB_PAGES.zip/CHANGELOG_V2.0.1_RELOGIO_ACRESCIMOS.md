# v2.0.1 — Relógio correndo e acréscimos

- O relógio da partida agora avança continuamente durante o jogo, em vez de ficar parado entre decisões.
- O tempo pausa automaticamente quando surge uma situação para o jogador decidir; depois da escolha, a partida continua do mesmo minuto.
- A tela de partida em andamento mostra placar, minuto e narração dos acontecimentos enquanto a bola rola.
- Acréscimos variáveis em cada tempo: +3, +5 ou +7 minutos, escolhidos de forma independente.
- O intervalo e o apito final respeitam os acréscimos definidos.
- O tempo também continua até a entrada do jogador que começa no banco.
- Os acréscimos também são respeitados nas partidas em que o atleta não foi relacionado.

---

