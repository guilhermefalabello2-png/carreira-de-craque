# Carreira de Craque v2.0.8 — Correção do botão IR A PARTIDA

- Corrigida a abertura da Central de pré-jogo: variáveis de data, dia da partida, árbitro e VAR agora são inicializadas antes de montar a tela.
- O dia e a data são calculados conforme o calendário da liga ou da Copa do Brasil.
- A arbitragem permanece estável ao reabrir o mesmo pré-jogo.
- O botão de confirmação mantém o fluxo: avança até o dia da partida quando necessário e só inicia o jogo após a confirmação.
- Nenhuma mecânica do motor de partida foi alterada.
