# v1.58.1 — Coletiva obrigatória pela tela Início

- Ao encerrar uma partida em que o atleta participou, a carreira passa a exibir na tela **Início** o botão **INICIAR COLETIVA PÓS JOGO**.
- A coletiva não é aberta automaticamente pelo relatório: o jogador entra nela pelo botão da tela Início.
- A próxima partida e o avanço de temporada continuam bloqueados enquanto houver coletiva pendente.
- A pendência fica salva no progresso, então o botão continua disponível após fechar/reabrir o jogo.
- Ao concluir as perguntas e a manchete, a pendência é removida e a carreira pode continuar normalmente.
