# v1.62.17 — Uniformes da LaLiga

- Implementadas prévias vetoriais de camisa para os 20 clubes cadastrados na LaLiga dentro de Dados do Jogador → Personalizar → Camisa do jogador.
- Barcelona: camisa titular com faixas verticais azul e grená, nome e número em dourado, seguindo a referência enviada pelo usuário.
- Real Madrid: camisa titular branca com nome e número pretos.
- Demais 18 clubes: cores e padrões individuais inspirados nas identidades tradicionais de cada equipe.
- Atualizado o cache do service worker.
- Não altera escudos, elencos, calendários, partidas, tabelas ou saves.

Observação: são prévias gráficas vetoriais inspiradas nos uniformes/identidades dos clubes, não fotografias oficiais nem réplicas licenciadas com patrocínios.
